# TabProxy
Web proxy with a tabbed interface. No dependencies, needs Node 18+.

Local:  node server.js  then open http://localhost:8080
Online: see DEPLOY.md. Set the ACCESS_PASSWORD environment variable whenever it is public.
