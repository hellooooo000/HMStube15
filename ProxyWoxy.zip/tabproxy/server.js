// TabProxy - zero-dependency web proxy (Node 18+)
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const dns = require('dns').promises;
const net = require('net');

const PORT = process.env.PORT || 8080;
const PREFIX = '/proxy?url=';
const PASSWORD = process.env.ACCESS_PASSWORD || '';
const AUTH_TOKEN = PASSWORD ? crypto.createHash('sha256').update('tp:' + PASSWORD).digest('hex') : null;
const jars = new Map(); // sessionId -> Map(host -> Map(name -> value))
const parseCookies = h => Object.fromEntries((h || '').split(';').map(c => c.trim().split(/=(.*)/s).slice(0, 2)).filter(p => p[0]));
const getJar = sid => { if (!jars.has(sid)) { if (jars.size > 2000) jars.delete(jars.keys().next().value); jars.set(sid, new Map()); } return jars.get(sid); };

function isPrivateIP(ip) {
  if (net.isIPv6(ip)) {
    const l = ip.toLowerCase();
    if (l.startsWith('::ffff:')) return isPrivateIP(l.slice(7));
    return l === '::1' || l === '::' || l.startsWith('fc') || l.startsWith('fd') || l.startsWith('fe80');
  }
  const [a, b] = ip.split('.').map(Number);
  return a === 10 || a === 127 || a === 0 || (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) || a >= 224 || (a === 100 && b >= 64 && b <= 127);
}
async function isSafeHost(host) {
  if (/^localhost$|\.local$|\.internal$/i.test(host)) return false;
  if (net.isIP(host)) return !isPrivateIP(host);
  try { const r = await dns.lookup(host, { all: true }); return r.length > 0 && r.every(x => !isPrivateIP(x.address)); } catch { return false; }
}

const loginPage = err => `<!DOCTYPE html><meta name=viewport content="width=device-width,initial-scale=1"><title>Sign in</title>
<body style="margin:0;height:100vh;display:flex;align-items:center;justify-content:center;background:#111827;color:#e5e7eb;font:16px system-ui">
<form method=post action=/login style="display:flex;flex-direction:column;gap:12px;width:280px;text-align:center">
<h2 style="margin:0">TabProxy</h2>${err ? '<div style="color:#f87171">Wrong password</div>' : ''}
<input type=password name=password placeholder=Password autofocus style="padding:12px;border-radius:8px;border:1px solid #374151;background:#1f2937;color:#e5e7eb">
<button style="padding:12px;border-radius:8px;border:0;background:#6366f1;color:#fff;cursor:pointer">Enter</button></form></body>`;

const abs = (u, base) => { try { return new URL(u, base).href; } catch { return null; } };
const wrap = (u, base) => {
  if (!u) return u;
  const t = u.trim();
  if (/^(data:|javascript:|mailto:|tel:|#|blob:|about:)/i.test(t)) return u;
  const a = abs(t, base);
  return a ? PREFIX + encodeURIComponent(a) : u;
};

function rewriteCSS(css, base) {
  return css
    .replace(/url\(\s*(['"]?)(.*?)\1\s*\)/gi, (m, q, u) => `url(${q}${wrap(u, base)}${q})`)
    .replace(/@import\s+(['"])(.*?)\1/gi, (m, q, u) => `@import ${q}${wrap(u, base)}${q}`);
}

const clientScript = (base) => `<script>(function(){
var BASE=${JSON.stringify(base)};
var P='/proxy?url=';
function px(u){try{if(u==null)return u;u=String(u);if(/^(data:|javascript:|mailto:|tel:|#|blob:|about:)/i.test(u))return u;
if(u.indexOf(P)===0||u.indexOf(location.origin+P)===0)return u;
var a=new URL(u,BASE).href;return /^https?:/i.test(a)?P+encodeURIComponent(a):u;}catch(e){return u;}}
var of=window.fetch;if(of)window.fetch=function(i,o){try{if(typeof i==='string'||i instanceof URL)i=px(i);else if(i&&i.url)i=new Request(px(i.url),i);}catch(e){}return of.call(this,i,o);};
var xo=XMLHttpRequest.prototype.open;XMLHttpRequest.prototype.open=function(m,u){arguments[1]=px(u);return xo.apply(this,arguments);};
var wo=window.open;window.open=function(u){return wo.call(window,px(u));};
var sa=Element.prototype.setAttribute;Element.prototype.setAttribute=function(n,v){if(/^(src|href|action|poster)$/i.test(n))v=px(v);return sa.call(this,n,v);};
[[HTMLImageElement,'src'],[HTMLScriptElement,'src'],[HTMLIFrameElement,'src'],[HTMLSourceElement,'src'],[HTMLMediaElement,'src'],[HTMLLinkElement,'href'],[HTMLAnchorElement,'href']].forEach(function(p){
try{var d=Object.getOwnPropertyDescriptor(p[0].prototype,p[1]);if(!d||!d.set)return;Object.defineProperty(p[0].prototype,p[1],{get:d.get,set:function(v){d.set.call(this,px(v));},configurable:true});}catch(e){}});
['pushState','replaceState'].forEach(function(k){var o=history[k];history[k]=function(s,t,u){try{if(u)BASE=new URL(u,BASE).href;report();}catch(e){}try{return o.call(history,s,t);}catch(e){}};});
document.addEventListener('click',function(e){var a=e.target.closest&&e.target.closest('a[href]');if(!a)return;var h=a.getAttribute('href');
if(a.target==='_blank'||a.target==='_new'){a.target='_self';}
var n=px(h);if(n!==h)a.setAttribute('href',n);},true);
document.addEventListener('submit',function(e){var f=e.target;if(!f||!f.getAttribute)return;
var m=(f.method||'get').toLowerCase();var act=f.getAttribute('action')||BASE;
if(m==='get'){e.preventDefault();var real;try{var raw=act.indexOf(P)===0?decodeURIComponent(act.slice(P.length)):new URL(act,BASE).href;real=new URL(raw,BASE);}catch(x){return;}
new FormData(f).forEach(function(v,k){if(typeof v==='string')real.searchParams.set(k,v);});location.href=P+encodeURIComponent(real.href);}
else{f.setAttribute('action',act);}},true);
function report(){try{parent.postMessage({type:'tp-nav',url:BASE,title:document.title},'*');}catch(e){}}
window.addEventListener('load',report);
new MutationObserver(report).observe(document.documentElement,{childList:true,subtree:true,characterData:true});
report();
})();</script>`;

function rewriteHTML(html, base) {
  html = html.replace(/<base\b[^>]*>/gi, '');
  html = html.replace(/\s(integrity|nonce|crossorigin)=("[^"]*"|'[^']*'|[^\s>]+)/gi, '');
  html = html.replace(/<meta[^>]+http-equiv=["']?content-security-policy["']?[^>]*>/gi, '');
  html = html.replace(/(\s(?:href|src|action|poster|data-src)=)(?:"([^"]*)"|'([^']*)')/gi, (m, attr, d, s) => {
    const v = (d !== undefined ? d : s).replace(/&amp;/g, '&');
    return `${attr}"${wrap(v, base).replace(/"/g, '&quot;')}"`;
  });
  html = html.replace(/(\ssrcset=)(?:"([^"]*)"|'([^']*)')/gi, (m, attr, d, s) => {
    const v = d !== undefined ? d : s;
    const out = v.split(',').map(part => {
      const bits = part.trim().split(/\s+/);
      bits[0] = wrap(bits[0], base);
      return bits.join(' ');
    }).join(', ');
    return `${attr}"${out}"`;
  });
  html = html.replace(/(<style\b[^>]*>)([\s\S]*?)(<\/style>)/gi, (m, a, css, c) => a + rewriteCSS(css, base) + c);
  html = html.replace(/(\sstyle=)(?:"([^"]*)"|'([^']*)')/gi, (m, attr, d, s) => `${attr}"${rewriteCSS(d !== undefined ? d : s, base)}"`);
  const script = clientScript(base);
  if (/<head[^>]*>/i.test(html)) return html.replace(/<head[^>]*>/i, m => m + script);
  return script + html;
}

function cookieHeader(host, sid) {
  const c = getJar(sid).get(host);
  if (!c) return undefined;
  return [...c].map(([k, v]) => `${k}=${v}`).join('; ');
}

function storeCookies(host, sid, setCookies) {
  if (!setCookies || !setCookies.length) return;
  const j = getJar(sid);
  if (!j.has(host)) j.set(host, new Map());
  const c = j.get(host);
  for (const sc of setCookies) {
    const [pair] = sc.split(';');
    const i = pair.indexOf('=');
    if (i > 0) c.set(pair.slice(0, i).trim(), pair.slice(i + 1).trim());
  }
}

const mime = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.svg': 'image/svg+xml', '.png': 'image/png' };

function serveStatic(req, res) {
  const p = req.url.split('?')[0];
  const file = path.join(__dirname, 'public', p === '/' ? 'index.html' : p);
  if (!file.startsWith(path.join(__dirname, 'public'))) { res.writeHead(403); return res.end(); }
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404); return res.end('Not found'); }
    res.writeHead(200, { 'Content-Type': mime[path.extname(file)] || 'application/octet-stream' });
    res.end(data);
  });
}

async function handleProxy(req, res, target, sid) {
  const body = await new Promise(r => { const b = []; req.on('data', d => b.push(d)); req.on('end', () => r(Buffer.concat(b))); });
  const url = new URL(target);
  if (!(await isSafeHost(url.hostname))) { res.writeHead(403, { 'Content-Type': 'text/plain' }); return res.end('Blocked address'); }
  const headers = {
    'user-agent': req.headers['user-agent'] || 'Mozilla/5.0',
    'accept': req.headers['accept'] || '*/*',
    'accept-language': req.headers['accept-language'] || 'en-US,en;q=0.9',
  };
  if (req.headers['content-type']) headers['content-type'] = req.headers['content-type'];
  if (req.headers['range']) headers['range'] = req.headers['range'];
  const ck = cookieHeader(url.host, sid);
  if (ck) headers['cookie'] = ck;
  headers['referer'] = url.origin + '/';

  const hasBody = !['GET', 'HEAD'].includes(req.method) && body.length;
  const upstream = await fetch(url, { method: req.method, headers, body: hasBody ? body : undefined, redirect: 'manual' });
  storeCookies(url.host, sid, upstream.headers.getSetCookie ? upstream.headers.getSetCookie() : []);

  if (upstream.status >= 300 && upstream.status < 400 && upstream.headers.get('location')) {
    res.writeHead(302, { Location: wrap(upstream.headers.get('location'), url.href) });
    return res.end();
  }

  const out = {};
  const skip = new Set(['x-frame-options', 'content-security-policy', 'content-security-policy-report-only', 'content-encoding', 'content-length', 'transfer-encoding', 'set-cookie', 'strict-transport-security', 'connection', 'keep-alive']);
  upstream.headers.forEach((v, k) => { if (!skip.has(k.toLowerCase())) out[k] = v; });
  const ct = (upstream.headers.get('content-type') || '').toLowerCase();
  const buf = Buffer.from(await upstream.arrayBuffer());

  if (ct.includes('text/html')) {
    res.writeHead(upstream.status, out);
    return res.end(rewriteHTML(buf.toString('utf8'), url.href));
  }
  if (ct.includes('text/css')) {
    res.writeHead(upstream.status, out);
    return res.end(rewriteCSS(buf.toString('utf8'), url.href));
  }
  res.writeHead(upstream.status, out);
  res.end(buf);
}

http.createServer(async (req, res) => {
  try {
    const u = new URL(req.url, 'http://localhost');
    const cookies = parseCookies(req.headers.cookie);
    const secure = req.headers['x-forwarded-proto'] === 'https' ? '; Secure' : '';
    const out = [];
    let sid = cookies.tp_sid;
    if (!sid) { sid = crypto.randomBytes(16).toString('hex'); out.push(`tp_sid=${sid}; Path=/; HttpOnly; SameSite=Lax${secure}`); }
    if (AUTH_TOKEN && cookies.tp_auth !== AUTH_TOKEN) {
      if (req.method === 'POST' && u.pathname === '/login') {
        const body = await new Promise(r => { let b = ''; req.on('data', d => { if (b.length < 4096) b += d; }); req.on('end', () => r(b)); });
        if (new URLSearchParams(body).get('password') === PASSWORD) {
          out.push(`tp_auth=${AUTH_TOKEN}; Path=/; HttpOnly; SameSite=Lax; Max-Age=2592000${secure}`);
          res.setHeader('Set-Cookie', out); res.writeHead(302, { Location: '/' }); return res.end();
        }
        res.setHeader('Set-Cookie', out); res.writeHead(401, { 'Content-Type': 'text/html' }); return res.end(loginPage(true));
      }
      res.setHeader('Set-Cookie', out); res.writeHead(401, { 'Content-Type': 'text/html' }); return res.end(loginPage(false));
    }
    if (out.length) res.setHeader('Set-Cookie', out);
    if (u.pathname === '/proxy') {
      const target = u.searchParams.get('url');
      if (!target || !/^https?:\/\//i.test(target)) { res.writeHead(400); return res.end('Bad url'); }
      return await handleProxy(req, res, target, sid);
    }
    // Fallback: a page requested a root-relative URL that slipped past rewriting
    const ref = req.headers.referer || '';
    const m = ref.match(/\/proxy\?url=([^&]+)/);
    if (m && u.pathname !== '/' && !fs.existsSync(path.join(__dirname, 'public', u.pathname))) {
      const real = abs(u.pathname + u.search, decodeURIComponent(m[1]));
      if (real) { res.writeHead(307, { Location: PREFIX + encodeURIComponent(real) }); return res.end(); }
    }
    serveStatic(req, res);
  } catch (e) {
    res.writeHead(502, { 'Content-Type': 'text/plain' });
    res.end('Proxy error: ' + e.message);
  }
}).listen(PORT, () => console.log(`TabProxy running on port ${PORT}` + (PASSWORD ? ' (password protected)' : ' (NO PASSWORD - local use only)')));
