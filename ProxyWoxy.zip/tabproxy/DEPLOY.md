# Put TabProxy online (Render, free)

You need two free accounts: GitHub and Render.

## 1. Upload the code to GitHub
1. Go to github.com, sign up or log in, click + (top right) > New repository.
2. Name it anything, set it to Private, click Create repository.
3. Click "uploading an existing file".
4. Unzip tabproxy.zip, open the folder, select EVERYTHING inside
   (server.js, package.json, render.yaml, the public folder, etc.) and drag it into the page.
   The public folder must keep its index.html inside it.
5. Click Commit changes.

## 2. Deploy on Render
1. Go to render.com and sign up with your GitHub account.
2. Click New + > Web Service and pick your repository.
3. Settings: Runtime Node, Build Command `echo ok`, Start Command `node server.js`, Instance Type Free.
4. Under Environment Variables add:  ACCESS_PASSWORD = (a password you choose)
5. Click Deploy. After a minute or two Render shows your link (something.onrender.com).

## 3. Use it
Open your link, enter the password, and browse. On the free plan the site sleeps
when unused, so the first load can take about 50 seconds.

## Good to know
- Don't share the password widely; the server and its bandwidth are free and limited.
- Hosts can suspend proxy sites, and your school's filter may block the link.
- Never log in to important accounts through it.
